import React from 'react';
import { motion } from 'framer-motion';
import Draggable from 'react-draggable';
import { CheckCircle, Circle, Clock, ArrowRight } from 'lucide-react';
import { RoadmapBlock as RoadmapBlockType } from '../types/roadmap';

interface RoadmapBlockProps {
  block: RoadmapBlockType;
  onToggleComplete: (blockId: number) => void;
  position: { x: number; y: number };
  onPositionChange: (blockId: number, position: { x: number; y: number }) => void;
}

const RoadmapBlock: React.FC<RoadmapBlockProps> = ({
  block,
  onToggleComplete,
  position,
  onPositionChange,
}) => {
  const handleDrag = (e: any, data: any) => {
    onPositionChange(block.blockID, { x: data.x, y: data.y });
  };

  return (
    <Draggable
      position={position}
      onDrag={handleDrag}
      handle=".drag-handle"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        whileHover={{ scale: 1.02 }}
        className={`absolute w-80 bg-white border-2 rounded-lg shadow-lg cursor-move ${
          block.isCompletedByUser
            ? 'border-green-400 bg-green-50'
            : 'border-blue-400 bg-blue-50'
        }`}
      >
        <div className="drag-handle p-4">
          <div className="flex items-start justify-between mb-3">
            <h3 className="text-lg font-semibold text-gray-800 pr-2">
              {block.title}
            </h3>
            <button
              onClick={() => onToggleComplete(block.blockID)}
              className="flex-shrink-0 text-gray-600 hover:text-gray-800 transition-colors"
            >
              {block.isCompletedByUser ? (
                <CheckCircle className="w-6 h-6 text-green-600" />
              ) : (
                <Circle className="w-6 h-6" />
              )}
            </button>
          </div>
          
          <div className="flex items-center mb-3 text-sm text-gray-600">
            <Clock className="w-4 h-4 mr-1" />
            <span>{block.time}</span>
          </div>
          
          <p className="text-sm text-gray-700 mb-3 leading-relaxed">
            {block.description}
          </p>
          
          {block.connectivity.length > 0 && (
            <div className="flex items-center text-xs text-gray-500">
              <ArrowRight className="w-3 h-3 mr-1" />
              <span>Connects to: {block.connectivity.join(', ')}</span>
            </div>
          )}
          
          <div className="absolute -top-2 -left-2 bg-blue-600 text-white text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center">
            {block.blockID}
          </div>
        </div>
      </motion.div>
    </Draggable>
  );
};

export default RoadmapBlock;
