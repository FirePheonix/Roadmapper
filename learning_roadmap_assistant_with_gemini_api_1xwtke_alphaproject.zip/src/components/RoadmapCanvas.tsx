import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import RoadmapBlock from './RoadmapBlock';
import { RoadmapBlock as RoadmapBlockType } from '../types/roadmap';

interface RoadmapCanvasProps {
  blocks: RoadmapBlockType[];
  onUpdateBlocks: (blocks: RoadmapBlockType[]) => void;
}

const RoadmapCanvas: React.FC<RoadmapCanvasProps> = ({ blocks, onUpdateBlocks }) => {
  const [blockPositions, setBlockPositions] = useState<Record<number, { x: number; y: number }>>({});

  useEffect(() => {
    // Initialize positions for new blocks
    const newPositions: Record<number, { x: number; y: number }> = {};
    blocks.forEach((block, index) => {
      if (!blockPositions[block.blockID]) {
        const row = Math.floor(index / 3);
        const col = index % 3;
        newPositions[block.blockID] = {
          x: col * 350 + 50,
          y: row * 250 + 50,
        };
      }
    });
    
    if (Object.keys(newPositions).length > 0) {
      setBlockPositions(prev => ({ ...prev, ...newPositions }));
    }
  }, [blocks, blockPositions]);

  const handleToggleComplete = (blockId: number) => {
    const updatedBlocks = blocks.map(block =>
      block.blockID === blockId
        ? { ...block, isCompletedByUser: !block.isCompletedByUser }
        : block
    );
    onUpdateBlocks(updatedBlocks);
  };

  const handlePositionChange = (blockId: number, position: { x: number; y: number }) => {
    setBlockPositions(prev => ({
      ...prev,
      [blockId]: position,
    }));
  };

  const drawConnections = () => {
    const connections: JSX.Element[] = [];
    
    blocks.forEach(block => {
      block.connectivity.forEach(targetId => {
        const sourcePos = blockPositions[block.blockID];
        const targetPos = blockPositions[targetId];
        
        if (sourcePos && targetPos) {
          const sourceX = sourcePos.x + 160; // Half of block width
          const sourceY = sourcePos.y + 100; // Approximate center height
          const targetX = targetPos.x + 160;
          const targetY = targetPos.y + 100;
          
          connections.push(
            <svg
              key={`${block.blockID}-${targetId}`}
              className="absolute top-0 left-0 pointer-events-none"
              style={{ zIndex: 1 }}
            >
              <defs>
                <marker
                  id={`arrowhead-${block.blockID}-${targetId}`}
                  markerWidth="10"
                  markerHeight="7"
                  refX="9"
                  refY="3.5"
                  orient="auto"
                >
                  <polygon
                    points="0 0, 10 3.5, 0 7"
                    fill="#6366f1"
                  />
                </marker>
              </defs>
              <line
                x1={sourceX}
                y1={sourceY}
                x2={targetX}
                y2={targetY}
                stroke="#6366f1"
                strokeWidth="2"
                strokeDasharray="5,5"
                markerEnd={`url(#arrowhead-${block.blockID}-${targetId})`}
              />
            </svg>
          );
        }
      });
    });
    
    return connections;
  };

  const completedCount = blocks.filter(block => block.isCompletedByUser).length;
  const progressPercentage = blocks.length > 0 ? (completedCount / blocks.length) * 100 : 0;

  return (
    <div className="relative">
      {/* Progress Bar */}
      <div className="fixed top-4 right-4 bg-white rounded-lg shadow-lg p-4 z-50">
        <div className="text-sm font-medium text-gray-700 mb-2">
          Progress: {completedCount}/{blocks.length} blocks
        </div>
        <div className="w-32 h-2 bg-gray-200 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-green-500"
            initial={{ width: 0 }}
            animate={{ width: `${progressPercentage}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </div>

      {/* Canvas */}
      <div className="relative min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 overflow-hidden">
        {/* Grid Background */}
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `
              linear-gradient(to right, #e5e7eb 1px, transparent 1px),
              linear-gradient(to bottom, #e5e7eb 1px, transparent 1px)
            `,
            backgroundSize: '20px 20px',
          }}
        />

        {/* Connections */}
        {drawConnections()}

        {/* Blocks */}
        {blocks.map(block => (
          <RoadmapBlock
            key={block.blockID}
            block={block}
            onToggleComplete={handleToggleComplete}
            position={blockPositions[block.blockID] || { x: 0, y: 0 }}
            onPositionChange={handlePositionChange}
          />
        ))}

        {blocks.length === 0 && (
          <div className="flex items-center justify-center h-full">
            <div className="text-center text-gray-500">
              <div className="text-6xl mb-4">🎯</div>
              <h3 className="text-xl font-medium mb-2">No roadmap yet</h3>
              <p>Enter your learning goal above to generate a roadmap</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RoadmapCanvas;
