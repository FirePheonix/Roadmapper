import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertCircle, Download, RefreshCw } from 'lucide-react';
import QueryInput from './components/QueryInput';
import RoadmapCanvas from './components/RoadmapCanvas';
import { generateRoadmap } from './services/geminiService';
import { RoadmapBlock, RoadmapData } from './types/roadmap';

function App() {
  const [roadmapData, setRoadmapData] = useState<RoadmapData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateRoadmap = async (query: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const blocks = await generateRoadmap(query);
      setRoadmapData({ blocks, query });
    } catch (error) {
      console.error('Error:', error);
      setError(error instanceof Error ? error.message : 'An unexpected error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateBlocks = (blocks: RoadmapBlock[]) => {
    if (roadmapData) {
      setRoadmapData({ ...roadmapData, blocks });
    }
  };

  const handleExportRoadmap = () => {
    if (roadmapData) {
      const dataStr = JSON.stringify(roadmapData, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `roadmap-${Date.now()}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  };

  const handleReset = () => {
    setRoadmapData(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <QueryInput onSubmit={handleGenerateRoadmap} isLoading={isLoading} />
      
      {/* Action Bar */}
      <AnimatePresence>
        {roadmapData && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="bg-white border-b border-gray-200 p-4"
          >
            <div className="max-w-4xl mx-auto flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold text-gray-900">
                  {roadmapData.query}
                </h2>
                <p className="text-sm text-gray-600">
                  {roadmapData.blocks.length} learning blocks generated
                </p>
              </div>
              <div className="flex gap-2">
                <motion.button
                  onClick={handleExportRoadmap}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  <Download className="w-4 h-4" />
                  Export JSON
                </motion.button>
                <motion.button
                  onClick={handleReset}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                >
                  <RefreshCw className="w-4 h-4" />
                  Reset
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Error Display */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="bg-red-50 border-l-4 border-red-400 p-4 mx-6 mt-4 rounded-r-lg"
          >
            <div className="flex items-start">
              <AlertCircle className="w-5 h-5 text-red-400 mr-3 mt-0.5" />
              <div>
                <h3 className="text-sm font-medium text-red-800">Error</h3>
                <p className="text-sm text-red-700 mt-1">{error}</p>
                <p className="text-xs text-red-600 mt-2">
                  Make sure you have set your Gemini API key in the .env file
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Loading State */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex items-center justify-center py-20"
          >
            <div className="text-center">
              <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Generating Your Learning Roadmap
              </h3>
              <p className="text-gray-600">
                AI is analyzing your request and creating structured learning blocks...
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Roadmap Canvas */}
      {roadmapData && !isLoading && (
        <RoadmapCanvas
          blocks={roadmapData.blocks}
          onUpdateBlocks={handleUpdateBlocks}
        />
      )}

      {/* Instructions */}
      {!roadmapData && !isLoading && !error && (
        <div className="max-w-4xl mx-auto p-6">
          <div className="bg-white rounded-lg shadow-sm p-8 text-center">
            <div className="text-6xl mb-6">🎓</div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Welcome to Your Learning Journey
            </h2>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Enter your learning goal above and let AI create a structured, interactive roadmap 
              that breaks down your journey into manageable, connected blocks. You can drag, 
              rearrange, and track your progress as you learn.
            </p>
            <div className="grid md:grid-cols-3 gap-6 text-left">
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl mb-2">🎯</div>
                <h3 className="font-semibold text-gray-900 mb-2">Smart Planning</h3>
                <p className="text-sm text-gray-600">
                  AI analyzes your goal and creates a logical progression of learning blocks
                </p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <div className="text-2xl mb-2">🔗</div>
                <h3 className="font-semibold text-gray-900 mb-2">Connected Learning</h3>
                <p className="text-sm text-gray-600">
                  Each block connects to others, showing prerequisites and next steps
                </p>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg">
                <div className="text-2xl mb-2">📊</div>
                <h3 className="font-semibold text-gray-900 mb-2">Progress Tracking</h3>
                <p className="text-sm text-gray-600">
                  Mark blocks as complete and visualize your learning progress
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
