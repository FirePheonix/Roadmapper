import { GoogleGenerativeAI } from '@google/generative-ai';
import { RoadmapBlock } from '../types/roadmap';

const genAI = new GoogleGenerativeAI(import.meta.env.VITE_GEMINI_API_KEY);

export const generateRoadmap = async (query: string): Promise<RoadmapBlock[]> => {
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    
    const prompt = `
You are an expert learning assistant. Based on the user's query, create a structured learning roadmap broken down into connected, modular blocks that represent distinct stages or topics in the skill development process.

For each stage, generate a JSON object with the following structure:
{
  "isCompletedByUser": false,
  "blockID": <unique number starting from 1>,
  "title": "<concise name of the topic being learned in this block>",
  "time": "<estimated time duration like '1-2 weeks'>",
  "description": "<a short explanation of what this block covers and why it's important>",
  "connectivity": [<blockIDs that come after this, representing dependencies>]
}

The response should be a JSON array (wrapped inside [ ]) of multiple blocks. These blocks should be logically connected using the connectivity field. Ensure that the order of blocks makes sense and represents a proper skill progression. The time estimate should reflect realistic learning durations for each block.

Only return the JSON array and nothing else. No introductions, no explanations — just clean, copy-pasteable JSON output.

User's query: "${query}"
`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    // Parse the JSON response
    const roadmapBlocks = JSON.parse(text.trim());
    return roadmapBlocks;
  } catch (error) {
    console.error('Error generating roadmap:', error);
    throw new Error('Failed to generate roadmap. Please check your API key and try again.');
  }
};
